/* =========================================================
   陈墨 · 个人网站脚本
   1. 主题切换   2. 导航   3. 滚动动效   4. 打字机
   5. 数字滚动   6. 光标光晕   7. 表单与复制   8. 杂项
   ========================================================= */
(function () {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 1. 主题切换 ---------- */
  const root = document.documentElement;
  const themeToggle = $('#themeToggle');

  function setTheme(theme) {
    root.dataset.theme = theme;
    try { localStorage.setItem('theme', theme); } catch (e) {}
    if (themeToggle) {
      themeToggle.setAttribute('aria-label', theme === 'light' ? '切换到深色主题' : '切换到浅色主题');
      themeToggle.title = themeToggle.getAttribute('aria-label');
    }
  }

  if (themeToggle) {
    setTheme(root.dataset.theme === 'light' ? 'light' : 'dark');
    themeToggle.addEventListener('click', () => {
      setTheme(root.dataset.theme === 'light' ? 'dark' : 'light');
    });
  }

  /* ---------- 2. 导航 ---------- */
  const nav = $('#nav');
  const burger = $('#burger');
  const mobileMenu = $('#mobileMenu');
  const navLinks = $$('.nav-links a');
  const sections = $$('main section[id]');

  function closeMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.remove('open');
    burger.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', '打开菜单');
    document.body.classList.remove('menu-open');
    mobileMenu.setAttribute('inert', '');
  }

  function openMenu() {
    mobileMenu.classList.add('open');
    burger.classList.add('open');
    burger.setAttribute('aria-expanded', 'true');
    burger.setAttribute('aria-label', '关闭菜单');
    document.body.classList.add('menu-open');
    mobileMenu.removeAttribute('inert');
  }

  if (burger && mobileMenu) {
    closeMenu();
    burger.addEventListener('click', () => {
      mobileMenu.classList.contains('open') ? closeMenu() : openMenu();
    });
    $$('a', mobileMenu).forEach((a) => a.addEventListener('click', closeMenu));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 860) closeMenu();
    });
  }

  /* 滚动：导航底色、进度条、回到顶部 */
  const progress = $('#progress');
  const toTop = $('#toTop');
  let ticking = false;

  function onScroll() {
    const y = window.scrollY || window.pageYOffset;
    if (nav) nav.classList.toggle('scrolled', y > 12);
    if (progress) {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = (max > 0 ? (y / max) * 100 : 0) + '%';
    }
    if (toTop) toTop.classList.toggle('show', y > 640);
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(onScroll);
    }
  }, { passive: true });
  onScroll();

  if (toTop) {
    toTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  }

  /* 当前区块高亮 */
  if ('IntersectionObserver' in window && sections.length) {
    const linkFor = (id) => navLinks.find((a) => a.getAttribute('href') === '#' + id);
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const link = linkFor(entry.target.id);
        if (!link) return;
        navLinks.forEach((a) => a.classList.remove('active'));
        link.classList.add('active');
      });
    }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });
    sections.forEach((s) => spy.observe(s));
  }

  /* ---------- 3. 滚动动效 ---------- */
  const revealEls = $$('.reveal');

  /* 同组元素依次出现，最多延迟 240ms */
  ['.hero-copy', '.about-text', '.skills', '.facts', '.work-grid', '.timeline', '.contact-card'].forEach((sel) => {
    const box = $(sel);
    if (!box) return;
    $$('.reveal', box).forEach((el, i) => {
      if (el.parentElement === box) {
        el.style.transitionDelay = Math.min(i * 70, 240) + 'ms';
      }
    });
  });

  function countUp(el) {
    if (el.dataset.done) return;
    el.dataset.done = '1';
    const to = Number(el.dataset.to || 0);
    const suffix = el.dataset.suffix || '';
    if (reduceMotion) { el.textContent = to + suffix; return; }
    const dur = 1300;
    const start = performance.now();
    function frame(now) {
      const p = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(to * eased) + (p === 1 ? suffix : '');
      if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  /* 用「滚动扫描」而不是 IntersectionObserver 的采样：
     快速滚动、锚点跳转、刷新后停在页面中部时都不会漏掉元素 */
  const pending = new Set(revealEls);

  function reveal(el) {
    if (!pending.has(el)) return;
    pending.delete(el);
    el.classList.add('in');
    $$('.stat-num', el).forEach(countUp);
    /* 依次入场的延迟用完就清掉，避免拖慢 hover 过渡 */
    const delay = parseFloat(el.style.transitionDelay) || 0;
    window.setTimeout(() => { el.style.transitionDelay = ''; }, delay + 900);
  }

  function sweep() {
    if (!pending.size) return;
    const limit = window.innerHeight * 0.92;
    pending.forEach((el) => {
      if (el.getBoundingClientRect().top < limit) reveal(el);
    });
  }

  let sweepQueued = false;
  let settleTimer;

  function queueSweep() {
    if (!pending.size) return;
    /* 兜底：滚动停下来后再扫一次，避免任何元素被漏掉 */
    window.clearTimeout(settleTimer);
    settleTimer = window.setTimeout(sweep, 240);
    if (sweepQueued) return;
    sweepQueued = true;
    window.requestAnimationFrame(() => { sweepQueued = false; sweep(); });
  }

  sweep();
  window.addEventListener('scroll', queueSweep, { passive: true });
  window.addEventListener('resize', queueSweep, { passive: true });
  window.addEventListener('load', queueSweep);

  /* ---------- 4. 打字机 ---------- */
  const typed = $('#typed');
  const roles = ['动效与交互', '品牌网站'];

  if (typed) {
    if (reduceMotion || roles.length === 0) {
      typed.textContent = roles[0] || '';
    } else {
      let roleIndex = 0;
      let charIndex = 0;
      let deleting = false;

      (function tick() {
        const word = roles[roleIndex];
        const step = deleting ? word.slice(0, --charIndex) : word.slice(0, ++charIndex);
        typed.textContent = step;

        let wait = deleting ? 55 : 120;
        if (!deleting && charIndex === word.length) {
          wait = 1900;
          deleting = true;
        } else if (deleting && charIndex <= 0) {
          deleting = false;
          roleIndex = (roleIndex + 1) % roles.length;
          wait = 380;
        }
        window.setTimeout(tick, wait);
      })();
    }
  }

  /* ---------- 5. 卡片光斑 ---------- */
  $$('.spot').forEach((card) => {
    card.addEventListener('pointermove', (e) => {
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
      card.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
    });
  });

  /* ---------- 6. 光标光晕（仅精确指针设备） ---------- */
  const glow = $('#cursorGlow');
  if (glow && window.matchMedia('(pointer: fine)').matches && !reduceMotion) {
    let tx = window.innerWidth / 2;
    let ty = window.innerHeight / 3;
    let cx = tx;
    let cy = ty;
    let shown = false;

    window.addEventListener('pointermove', (e) => {
      tx = e.clientX;
      ty = e.clientY;
      if (!shown) { shown = true; glow.style.opacity = '1'; }
    }, { passive: true });

    (function follow() {
      cx += (tx - cx) * 0.09;
      cy += (ty - cy) * 0.09;
      glow.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
      requestAnimationFrame(follow);
    })();
  }

  /* ---------- 7. 表单与复制 ---------- */
  const toast = $('#toast');
  let toastTimer;

  function showToast(msg) {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2400);
  }

  const mail = '19935039308';
  const copyBtn = $('#copyMail');

  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(mail);
        showToast('邮箱已复制 ' + mail);
      } catch (e) {
        const ta = document.createElement('textarea');
        ta.value = mail;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); showToast('邮箱已复制 ' + mail); }
        catch (err) { showToast('请手动复制：' + mail); }
        document.body.removeChild(ta);
      }
    });
  }

  /* ---------- 表单 ----------
     两种提交方式：
       netlify → 浏览器原生提交表单，留言存进 Netlify 后台（Forms → contact）可以查看。
                 （换成 Formspree 也是这个方式，只改 HTML 里的 action 即可）
       mailto  → 调起访客的邮件客户端（本地预览时的兜底，不会存任何东西）

     部署到 Netlify 后会自动用 netlify 方式。
     如果你绑了自己的域名，把 CUSTOM_DOMAIN 改成它，否则会一直用 mailto 兜底。 */
  const FORM_MODE = 'auto';        // 'auto' | 'netlify' | 'mailto'
  const CUSTOM_DOMAIN = '';        // 例如 'wangzixuan.com'，绑定域名后填

  function useNetlifyForms() {
    if (FORM_MODE === 'netlify') return true;
    if (FORM_MODE === 'mailto') return false;
    const h = location.hostname;
    if (/(^|\.)netlify\.app$/.test(h)) return true;
    if (CUSTOM_DOMAIN && (h === CUSTOM_DOMAIN || h.endsWith('.' + CUSTOM_DOMAIN))) return true;
    return false;
  }

  const form = $('#contactForm');
  const formMsg = $('#formMsg');

  if (form) {
    form.addEventListener('submit', (e) => {
      if (!form.checkValidity()) {
        e.preventDefault();
        form.reportValidity();
        if (formMsg) formMsg.textContent = '请把三项都填一下再发送。';
        return;
      }

      /* 交给 Netlify 原生提交，成功后跳到 /thanks.html */
      if (useNetlifyForms()) {
        if (formMsg) formMsg.textContent = '正在发送…';
        return;
      }

      /* 本地 / 非 Netlify 环境：退回邮件客户端 */
      e.preventDefault();
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const email = String(data.get('email') || '').trim();
      const message = String(data.get('message') || '').trim();

      const subject = encodeURIComponent(`来自 ${name} 的留言`);
      const body = encodeURIComponent(`${message}\n\n——\n${name}\n${email}`);
      window.location.href = `mailto:${mail}?subject=${subject}&body=${body}`;

      if (formMsg) formMsg.textContent = '已打开邮件客户端。如果没反应，可以直接复制上面的联系方式。';
    });
  }

  /* ---------- 8. 杂项 ---------- */
  const yearEl = $('#year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* 让锚点跳转在移动端菜单关闭后依然生效 */
  $$('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', () => {
      if (document.body.classList.contains('menu-open')) closeMenu();
    });
  });
})();
